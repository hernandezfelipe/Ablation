var a00016 =
[
    [ "__init__", "a00016.html#a48480cde91099915b503dbc0b0da4267", null ],
    [ "__enter__", "a00016.html#ae2a4b84793c5b03c339e8cae2ba8d594", null ],
    [ "__exit__", "a00016.html#a48e8093730533a8489ecc409eb75e475", null ],
    [ "__str__", "a00016.html#ad71f0894aa3d40f80d2dc08c248eb3ce", null ],
    [ "answersize", "a00016.html#ab0aab6813a503508eaf24bb1d6803628", null ],
    [ "close", "a00016.html#a58a219adb63dd3edb4298c5339305f57", null ],
    [ "connectionid", "a00016.html#a2ccb47cc1ece6ef0ab7c325669367c28", null ],
    [ "getanswer", "a00016.html#a134a11cd64442327f4f4ff52e4837762", null ],
    [ "send", "a00016.html#a7ae5a4f01f417ee81c9dc1b3ae502ff9", null ],
    [ "__buffer", "a00016.html#aac0b93d9b4ffd86bb5bf61f8428bb9ef", null ],
    [ "__ip", "a00016.html#a1a5705a831799dbce15d2d2884df27fd", null ],
    [ "__socket", "a00016.html#a720375fcf6c064a3fbe491db9582df01", null ]
];