var a00015 =
[
    [ "__str__", "a00015.html#a345c98773c76939917df3f2950014612", null ],
    [ "answersize", "a00015.html#abac2c8595824adbeaade172bba1e0e09", null ],
    [ "connectionid", "a00015.html#a815a354d5d9ec98e87893bd486c3d549", null ],
    [ "getanswer", "a00015.html#a3130d64a2f92baa675068d9d9dd40259", null ],
    [ "send", "a00015.html#a24a1ab90102cc9c4b29861f36d7cd0c3", null ],
    [ "__metaclass__", "a00015.html#a37c506eb7559be70db08dcb7928b2fa4", null ]
];