var a00045 =
[
    [ "gcsdll", "a00046.html", "a00046" ],
    [ "pigateway", "a00047.html", "a00047" ],
    [ "pisocket", "a00048.html", "a00048" ]
];