var a00031 =
[
    [ "GCSDll", "a00011.html", "a00011" ],
    [ "get_dll_name", "a00031.html#a46b3d30be220c2dc4be52a6fd4549f12", null ],
    [ "get_dll_path", "a00031.html#a2e09190b92c5eecc2f3bf6dd7e5da0c8", null ],
    [ "get_gcstranslator_dir", "a00031.html#a8fd164a701882463940508427f1f3090", null ],
    [ "DLLDEVICES", "a00031.html#ab6d18ee886b69453a2189604838484b5", null ],
    [ "UNIXDLL", "a00031.html#a13969315ed4bade123264e00a1d90bd0", null ]
];