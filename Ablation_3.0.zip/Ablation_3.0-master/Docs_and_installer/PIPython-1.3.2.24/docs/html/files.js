var files =
[
    [ "__init__.py", "a00026.html", "a00026" ],
    [ "interfaces/__init__.py", "a00027.html", null ],
    [ "datarectools.py", "a00028.html", "a00028" ],
    [ "gcscommands.py", "a00029.html", "a00029" ],
    [ "gcsdevice.py", "a00030.html", [
      [ "GCSDevice", "a00010.html", "a00010" ]
    ] ],
    [ "gcsdll.py", "a00031.html", "a00031" ],
    [ "gcserror.py", "a00032.html", "a00032" ],
    [ "gcsmessages.py", "a00033.html", "a00033" ],
    [ "pigateway.py", "a00035.html", [
      [ "PIGateway", "a00015.html", "a00015" ]
    ] ],
    [ "pisocket.py", "a00036.html", [
      [ "PISocket", "a00016.html", "a00016" ]
    ] ],
    [ "pitools.py", "a00037.html", "a00037" ],
    [ "replyserver.py", "a00038.html", "a00038" ]
];