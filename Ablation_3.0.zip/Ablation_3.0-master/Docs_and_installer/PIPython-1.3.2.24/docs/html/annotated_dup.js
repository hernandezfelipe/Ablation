var annotated_dup =
[
    [ "pipython", "a00039.html", "a00039" ]
];